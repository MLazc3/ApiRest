<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {

    
        $db = \Config\Database::connect();
        $query = $db->query('SELECT * FROM cliente');
        $valor = $query->getResult();

        return $this->response->setJSON($valor);
    }

        //$valor=[
           // 'Nombre: '=>'María',
            //'Apellido: '=>'Laz'

        //];
       
        //return view('welcome_message');
    }

