<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Cliente extends Controller {

    public function insertar() {
        // Obtener los datos enviados desde Postman
        $data = $this->request->getJSON(true);

        // Validar los datos
        $validation = \Config\Services::validation();
        $validation->setRules([
            'id_cliente' => 'required|integer',
            'nombres' => 'required|max_length[100]',
            'direccion' => 'max_length[255]',
            'telefono' => 'max_length[15]',
            'correo' => 'required|max_length[255]|valid_email',
            'sexo' => 'required|in_list[Femenino,Masculino,Otro]',
            'estado_civil' => 'required|in_list[Casado,Divorciado,Soltero,Viudo]',
            'numero_factura' => 'required|integer|is_unique[cliente.numero_factura,id_cliente,{id_cliente}]' // Excepción para el mismo id_cliente
        ]);

        if (!$validation->run($data)) {
            // Responder con errores de validación
            return $this->response->setStatusCode(400)
                                  ->setJSON(['status' => 'error', 'message' => $validation->getErrors()]);
        } else {
            // Insertar los datos en la base de datos
            $db = \Config\Database::connect();
            $builder = $db->table('cliente');
            if ($builder->insert($data)) {
                return $this->response->setStatusCode(201)
                                      ->setJSON(['status' => 'success', 'message' => 'Cliente insertado correctamente']);
            } else {
                return $this->response->setStatusCode(500)
                                      ->setJSON(['status' => 'error', 'message' => 'Error al insertar el cliente']);
            }
        }
    }

    public function actualizar($id) {
        // Obtener los datos enviados desde Postman
        $data = $this->request->getJSON(true);
    
        // Reemplazar el placeholder {id_cliente} con el valor real de $id
        $unique_rule = "is_unique[cliente.numero_factura,id_cliente,{$id}]";
    
        // Validar los datos
        $validation = \Config\Services::validation();
        $validation->setRules([
            'nombres' => 'required|max_length[100]',
            'direccion' => 'max_length[255]',
            'telefono' => 'max_length[15]',
            'correo' => 'required|max_length[255]|valid_email',
            'sexo' => 'required|in_list[Femenino,Masculino,Otro]',
            'estado_civil' => 'required|in_list[Casado,Divorciado,Soltero,Viudo]',
            'numero_factura' => "required|integer|$unique_rule"
        ]);
    
        if (!$validation->run($data)) {
            // Responder con errores de validación
            return $this->response->setStatusCode(400)
                                  ->setJSON(['status' => 'error', 'message' => $validation->getErrors()]);
        } else {
            // Actualizar los datos en la base de datos
            $db = \Config\Database::connect();
            $builder = $db->table('cliente');
            $builder->where('id_cliente', $id);
            if ($builder->update($data)) {
                return $this->response->setStatusCode(200)
                                      ->setJSON(['status' => 'success', 'message' => 'Cliente actualizado correctamente']);
            } else {
                return $this->response->setStatusCode(500)
                                      ->setJSON(['status' => 'error', 'message' => 'Error al actualizar el cliente']);
            }
        }
    }
    

    public function eliminar($id) {
        // Conectar a la base de datos
        $db = \Config\Database::connect();
        $builder = $db->table('cliente');
        
        // Verificar si el cliente existe
        $cliente = $builder->getWhere(['id_cliente' => $id])->getRow();
        if (!$cliente) {
            return $this->response->setStatusCode(404)
                                  ->setJSON(['status' => 'error', 'message' => 'Cliente no encontrado']);
        }

        // Eliminar el cliente
        if ($builder->delete(['id_cliente' => $id])) {
            return $this->response->setStatusCode(200)
                                  ->setJSON(['status' => 'success', 'message' => 'Cliente eliminado correctamente']);
        } else {
            return $this->response->setStatusCode(500)
                                  ->setJSON(['status' => 'error', 'message' => 'Error al eliminar el cliente']);
        }
    }


    public function filtrarPorGenero() {
        // Obtener los parámetros de la solicitud GET
        $params = $this->request->getGet();
        
        // Conectar a la base de datos
        $db = \Config\Database::connect();
        $builder = $db->table('cliente');

        // Seleccionar solo los campos id_cliente, nombres, y sexo
        $builder->select('id_cliente, nombres, sexo');

        // Filtrar por género si está presente en los parámetros
        if (isset($params['genero'])) {
            $genero = strtolower($params['genero']);
            if (in_array($genero, ['femenino', 'masculino', 'otro'])) {
                $builder->where('sexo', ucfirst($genero));
            } else {
                return $this->response->setStatusCode(400)
                                      ->setJSON(['status' => 'error', 'message' => 'Género no válido. Los valores permitidos son Femenino, Masculino, Otro.']);
            }
        }

        // Ejecutar la consulta
        $query = $builder->get();

        // Obtener los resultados
        $resultados = $query->getResult();

        // Responder con los datos obtenidos
        return $this->response->setStatusCode(200)
                              ->setJSON(['status' => 'success', 'data' => $resultados]);
    }

    public function filtrarPorDireccion() {
        // Obtener los parámetros de la solicitud GET
        $params = $this->request->getGet();

        // Conectar a la base de datos
        $db = \Config\Database::connect();
        $builder = $db->table('cliente');

        // Seleccionar solo los campos id_cliente, nombres, y direccion
        $builder->select('id_cliente, nombres, direccion');

        // Filtrar por dirección si está presente en los parámetros
        if (isset($params['direccion'])) {
            $direccion = $params['direccion'];
            $builder->like('direccion', $direccion);
        }

        // Ejecutar la consulta
        $query = $builder->get();

        // Obtener los resultados
        $resultados = $query->getResult();

        // Responder con los datos obtenidos
        return $this->response->setStatusCode(200)
                              ->setJSON(['status' => 'success', 'data' => $resultados]);
    }
}



