<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */


$routes->get('/medranda', 'Home::index');



$routes->post('medranda/cliente/insertar', 'Cliente::insertar');
$routes->put('medranda/cliente/actualizar/(:num)', 'Cliente::actualizar/$1');
$routes->delete('medranda/cliente/eliminar/(:num)', 'Cliente::eliminar/$1');
$routes->get('medranda/cliente/filtrar', 'Cliente::filtrarPorGenero');
$routes->get('medranda/cliente/filtrarDireccion', 'Cliente::filtrarPorDireccion');




