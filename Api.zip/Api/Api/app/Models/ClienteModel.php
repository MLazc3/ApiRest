<?php
class ClienteModel extends CI_Model {

    public function insertar_datos($data) {
        // Inserta los datos en la tabla 'CLIENTE'
        $this->db->insert('CLIENTE', $data);

        // Verifica si la inserción fue exitosa
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
